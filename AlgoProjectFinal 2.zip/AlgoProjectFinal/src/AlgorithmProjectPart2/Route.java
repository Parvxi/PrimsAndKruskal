
package AlgorithmProjectPart2;

import graphFramework.Edge;
import graphFramework.Vertex;



public class Route extends Edge {

	public Route(Vertex source, Vertex target, int weight) {
		super(source, target, weight);
	} // End of Method

	// Methods
	@Override
	public void displayInfo() {

	} // End of Method

} // End of Class